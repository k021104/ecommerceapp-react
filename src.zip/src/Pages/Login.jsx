// import React, { useContext, useState } from "react";
// import { AuthContext } from "../Context/AuthContext";
// import {
//     Box,
//     TextField,
//     Typography,
//     Button,
//     Card,
//     CardContent
// } from "@mui/material";
// import { Link } from "react-router-dom";


// export default function Login() {

//     const { login } = useContext(AuthContext);

//     const [username, setUsername] = useState("");
//     const [password, setPassword] = useState("");

//     const handleLogin = async (e) => {
//         e.preventDefault();
//         const success = await login(username, password);
//         if (success) {
//             alert("Login Successful 🎉");
//             // yaha navigate kar sakti ho
//         }
//     };

//     return (
//         <Box
//             sx={{
//                 minHeight: "100vh",
//                 display: "flex",
//                 justifyContent: "center",
//                 alignItems: "center",
//                 background: "linear-gradient(135deg, #e0e7ff, #fdf2f8)"
//             }}
//         >
//             <Card
//                 sx={{
//                     width: { xs: "90%", sm: 400 },
//                     borderRadius: "15px",
//                     boxShadow: "0 10px 30px rgba(0,0,0,.2)"
//                 }}
//             >
//                 <CardContent>
//                     <Typography
//                         variant="h4"
//                         sx={{ textAlign: "center", fontWeight: 700, mb: 3 }}
//                     >
//                         Login
//                     </Typography>

//                     <form onSubmit={handleLogin}>
//                         <TextField
//                             label="Username"
//                             fullWidth
//                             sx={{ mb: 2 }}
//                             value={username}
//                             onChange={(e) => setUsername(e.target.value)}
//                         />

//                         <TextField
//                             label="Password"
//                             type="password"
//                             fullWidth
//                             sx={{ mb: 3 }}
//                             value={password}
//                             onChange={(e) => setPassword(e.target.value)}
//                         />

//                         <Button
//                             type="submit"
//                             fullWidth
//                             variant="contained"
//                             sx={{
//                                 py: 1,
//                                 fontSize: "16px",
//                                 borderRadius: "10px",
//                                 textTransform: "none",
//                             }}
//                         >
//                             Login
//                         </Button>
//                     </form>

//                     <Typography sx={{ textAlign: "center", mt: 2, color: "gray" }}>
//                         Don't have an account?{" "}
//                         <Link to="/register" style={{ color: "#1976d2", textDecoration: "none" }}>
//                             Create Account
//                         </Link>
//                     </Typography>

//                 </CardContent>
//             </Card>
//         </Box>
//     );
// }


import React, { useContext, useState } from "react";
import { AuthContext } from "../Context/AuthContext";
import { Box, TextField, Typography, Button, Card, CardContent } from "@mui/material";
import { Link } from "react-router-dom";
import { useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";

export default function Login() {

    const { login } = useContext(AuthContext);
    const navigate = useNavigate();

    const location = useLocation();
    const redirectPath = location.state?.from || "/";

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [errors, setErrors] = useState({});

    const validate = () => {
        let temp = {};

        // username check
        if (!username) temp.username = "Username is required";
        else if (username.length < 4)
            temp.username = "Username must be at least 4 characters";

        // password check
        if (!password) temp.password = "Password is required";
        else if (password.length < 6)
            temp.password = "Password must be at least 6 characters";

        setErrors(temp);

        return Object.keys(temp).length === 0;
    };

    const handleLogin = (e) => {
        e.preventDefault();

        if (!validate()) return;

        const success = login(username, password);

        if (success) {
            navigate(redirectPath, { replace: true });
        }
    };


    return (
        <Box
            sx={{
                minHeight: "100vh",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                // background: "linear-gradient(135deg, #e0e7ff, #fdf2f8)"/
            }}
        >
            <Card sx={{ width: { xs: "90%", sm: 400 }, borderRadius: "15px", boxShadow: "0 10px 30px rgba(0,0,0,.2)" }}>
                <CardContent>
                    <Typography variant="h4" sx={{ textAlign: "center", fontWeight: 700, mb: 3 }}>Login</Typography>

                    <form onSubmit={handleLogin} autoComplete="off">
                        <TextField label="Username" fullWidth sx={{ mb: 2 }} value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            error={!!errors.username}
                            helperText={errors.username} />
                        <TextField label="Password" type="password" fullWidth sx={{ mb: 3 }} value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            error={!!errors.password}
                            helperText={errors.password} />
                        <Typography sx={{ textAlign: "center", mb: 1 }}>
                            <Link to="/forgot-password" style={{ color: "#1976d2", textDecoration: "none" }}>
                                Forgot Password?
                            </Link>
                        </Typography>

                        <Button type="submit" fullWidth variant="contained" sx={{ py: 1, fontSize: "16px", borderRadius: "10px", textTransform: "none" }}>Login</Button>
                    </form>

                    <Typography sx={{ textAlign: "center", mt: 2, color: "gray" }}>
                        Don't have an account?{" "}
                        <Link to="/register" style={{ color: "#1976d2", textDecoration: "none" }}>Create Account</Link>
                    </Typography>
                </CardContent>
            </Card>
        </Box>
    );
}
