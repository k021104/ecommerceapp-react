import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Box, Typography, Button, Rating } from "@mui/material";
import { useContext } from "react";
import { CartContext } from "../Context/CartContext";

export default function ProductDetails() {

    const { id } = useParams();
    const [product, setProduct] = useState(null);

    const { addToCart } = useContext(CartContext);

    useEffect(() => {
        fetch(`https://fakestoreapi.com/products/${id}`)
            .then(res => res.json())
            .then(result => setProduct(result));
    }, [id]);

    if (!product) return (
        <Typography sx={{ textAlign: "center", mt: 10, fontSize: 20 }}>
            Loading...
        </Typography>
    );

    return (
        <Box
            sx={{
                p: { xs: 3, md: 8 },
                display: "grid",
                gridTemplateColumns: { xs: "1fr", md: "1fr 1.2fr" },
                gap: 6,
                alignItems: "center",
            }}
        >

            {/* LEFT IMAGE */}
            <Box
                sx={{
                    flex: { xs: "100%", md: "45%" },
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    p: 4,
                    borderRadius: "20px",
                    boxShadow:
                        "0 15px 30px rgba(0,0,0,0.2), inset 0 0 15px rgba(255,255,255,0.5)",
                    transition: "all 0.4s ease-in-out",
                    "&:hover": {
                        boxShadow:
                            "0 25px 45px rgba(0,0,0,0.3), inset 0 0 20px rgba(255,255,255,0.7)",
                    },
                }}
            >
                <img
                    src={product?.image}
                    alt={product?.title}
                    style={{
                        width: "80%",
                        height: "auto",
                        objectFit: "contain",
                        filter: "drop-shadow(0px 20px 35px rgba(0,0,0,0.4))",
                        transition: "transform 0.4s ease",
                    }}
                    onMouseOver={(e) => (e.currentTarget.style.transform = "scale(1.05)")}
                    onMouseOut={(e) => (e.currentTarget.style.transform = "scale(1)")}
                />
            </Box>

            {/* RIGHT CONTENT */}
            <Box>
                <Typography sx={{ fontSize: 28, fontWeight: 800 }}>
                    {product.title}
                </Typography>

                <Typography sx={{ color: "#6b7280", mt: 1, fontSize: 15 }}>
                    {product.category?.toUpperCase()}
                </Typography>

                <Box sx={{ display: "flex", alignItems: "center", gap: 1, mt: 1 }}>
                    <Rating value={product.rating?.rate} precision={0.5} readOnly />
                    <Typography>({product.rating?.count} Reviews)</Typography>
                </Box>

                <Typography
                    sx={{
                        mt: 2,
                        color: "#374151",
                        fontSize: 15,
                        lineHeight: "24px",
                    }}
                >
                    {product.description}
                </Typography>

                <Typography
                    sx={{
                        mt: 2,
                        fontWeight: 900,
                        color: "#2563eb",
                        fontSize: 30,
                    }}
                >
                    ${product.price}
                </Typography>

                <Button
                    variant="contained"
                    sx={{
                        mt: 3,
                        background: "#111827",
                        px: 4,
                        py: 1.5,
                        fontSize: 16,
                        borderRadius: "30px",
                        "&:hover": { background: "#000" },
                    }}
                    onClick={() => addToCart(product)}
                >
                    Add to Cart
                </Button>
            </Box>
        </Box>
    );
}
