// import React from "react";
// import { Box, Container, Grid, Typography, TextField, Button, IconButton, Divider } from "@mui/material";
// import { Facebook, Instagram, Twitter, LinkedIn } from "@mui/icons-material";
// import { Link } from "react-router-dom";

// export default function Footer() {
//   // Common styling for links to avoid repetition
//   const linkStyle = {
//     color: "#9ca3af",
//     textDecoration: "none",
//     fontSize: "0.95rem",
//     position: "relative",
//     transition: "all 0.3s ease",
//     display: "inline-block",
//     "&:hover": {
//       color: "#3b82f6", // Brighter blue
//       transform: "translateX(5px)", // Subtle slide effect
//     },
//   };

//   return (
//     <Box component="footer" sx={{ backgroundColor: "#0f172a", color: "#fff", pt: 10, pb: 4 }}>
//       <Container maxWidth="lg">
//         <Grid container spacing={4}>
//           {/* Brand Section */}
//           <Grid item xs={12} md={4}>
//             <Typography
//               variant="h5"
//               sx={{
//                 fontWeight: 900,
//                 mb: 2,
//                 letterSpacing: 1,
//                 background: "linear-gradient(90deg, #60a5fa, #2563eb)",
//                 WebkitBackgroundClip: "text",
//                 WebkitTextFillColor: "transparent",
//               }}
//             >
//               GiftStore
//             </Typography>
//             <Typography sx={{ color: "#9ca3af", fontSize: "0.9rem", lineHeight: 1.8, pr: { md: 5 } }}>
//               Premium gifts for every occasion. We provide high-quality products with fast delivery and a 100% satisfaction guarantee.
//             </Typography>
//           </Grid>

//           {/* Navigation Links */}
//           <Grid item xs={6} sm={4} md={2}>
//             <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 3, color: "#f8fafc" }}>
//               Quick Links
//             </Typography>
//             <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5 }}>
//               {["Home", "Shop", "About", "Contact"].map((item) => (
//                 <Box
//                   key={item}
//                   component={Link}
//                   to={item === "Home" ? "/" : `/${item.toLowerCase()}`}
//                   sx={linkStyle}
//                 >
//                   {item}
//                 </Box>
//               ))}
//             </Box>
//           </Grid>

//           {/* Categories Section */}
//           <Grid item xs={6} sm={4} md={2}>
//             <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 3, color: "#f8fafc" }}>
//               Categories
//             </Typography>
//             <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5 }}>
//               {["Electronics", "Jewelry", "Men's Fashion", "Women's Fashion"].map((cat) => (
//                 <Box
//                   key={cat}
//                   component={Link}
//                   to={`/category/${cat.toLowerCase()}`}
//                   sx={linkStyle}
//                 >
//                   {cat}
//                 </Box>
//               ))}
//             </Box>
//           </Grid>

//           {/* Newsletter Section */}
//           <Grid item xs={12} sm={4} md={4}>
//             <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 3, color: "#f8fafc" }}>
//               Newsletter
//             </Typography>
//             <Typography sx={{ color: "#9ca3af", fontSize: "0.85rem", mb: 2 }}>
//               Subscribe to get special offers and once-in-a-lifetime deals.
//             </Typography>
//             <Box sx={{ display: "flex", flexWrap: "nowrap", gap: 0 }}>
//               <TextField
//                 placeholder="Email Address"
//                 variant="outlined"
//                 size="small"
//                 fullWidth
//                 sx={{
//                   backgroundColor: "#1e293b",
//                   borderRadius: "4px 0 0 4px",
//                   "& .MuiOutlinedInput-root": {
//                     color: "white",
//                     "& fieldset": { borderColor: "#334155" },
//                     "&:hover fieldset": { borderColor: "#2563eb" },
//                   },
//                 }}
//               />
//               <Button
//                 variant="contained"
//                 sx={{
//                   borderRadius: "0 4px 4px 0",
//                   textTransform: "none",
//                   fontWeight: 600,
//                   px: 3,
//                   backgroundColor: "#2563eb",
//                   "&:hover": { backgroundColor: "#1d4ed8" },
//                 }}
//               >
//                 Join
//               </Button>
//             </Box>

//             {/* Social Icons */}
//             <Box sx={{ mt: 3, display: "flex", gap: 1 }}>
//               {[Facebook, Instagram, Twitter, LinkedIn].map((Icon, idx) => (
//                 <IconButton
//                   key={idx}
//                   size="small"
//                   sx={{
//                     color: "#9ca3af",
//                     backgroundColor: "#1e293b",
//                     transition: "0.3s",
//                     "&:hover": { 
//                       color: "#fff", 
//                       backgroundColor: "#2563eb",
//                       transform: "translateY(-3px)" 
//                     },
//                   }}
//                 >
//                   <Icon fontSize="small" />
//                 </IconButton>
//               ))}
//             </Box>
//           </Grid>
//         </Grid>

//         <Divider sx={{ mt: 8, mb: 4, borderColor: "rgba(255,255,255,0.05)" }} />

//         {/* Bottom Bar */}
//         <Box sx={{ 
//           display: "flex", 
//           flexDirection: { xs: "column", sm: "row" }, 
//           justifyContent: "space-between", 
//           alignItems: "center",
//           gap: 2
//         }}>
//           <Typography sx={{ color: "#64748b", fontSize: "0.85rem" }}>
//             © {new Date().getFullYear()} GiftStore Inc. All rights reserved.
//           </Typography>
//           <Box sx={{ display: "flex", gap: 3 }}>
//             <Typography component={Link} to="/privacy" sx={{ color: "#64748b", fontSize: "0.85rem", textDecoration: "none", "&:hover": { color: "#fff" } }}>
//               Privacy Policy
//             </Typography>
//             <Typography component={Link} to="/terms" sx={{ color: "#64748b", fontSize: "0.85rem", textDecoration: "none", "&:hover": { color: "#fff" } }}>
//               Terms of Service
//             </Typography>
//           </Box>
//         </Box>
//       </Container>
//     </Box>
//   );
// }
// // ===========================================================
// import React from "react";
// import { Box, Container, Grid, Typography, TextField, Button, IconButton, Divider, Stack } from "@mui/material";
// import { Facebook, Instagram, Twitter, LinkedIn } from "@mui/icons-material";
// import { Link } from "react-router-dom";

// export default function Footer() {
//   // Link hover style with translateX (using sx for proper hover support)
//   const linkStyle = {
//     color: "#64748b", // Slate 500
//     textDecoration: "none",
//     fontSize: "0.9rem",
//     fontWeight: 500,
//     transition: "all 0.3s ease-in-out",
//     "&:hover": {
//       color: "#2563eb",
//       transform: "translateX(5px)",
//     },
//   };

//   // Bottom link style
//   const bottomLinkStyle = {
//     color: "#94a3b8",
//     fontSize: "0.85rem",
//     textDecoration: "none",
//     transition: "all 0.3s",
//     "&:hover": {
//       transform: "translateX(3px)",
//     },
//   };

//   return (
//     <Box component="footer" sx={{ 
//       backgroundColor: "#fcfcfc", 
//       color: "#1e293b", 
//       pt: { xs: 8, md: 12 }, 
//       pb: 6,
//       borderTop: "1px solid #e5e7eb", // Subtle top border to delineate the footer
//       boxShadow: "0px -2px 4px rgba(0, 0, 0, 0.05)", // Optional subtle top shadow for depth
//     }}>
//       <Container maxWidth="lg">
//         <Grid container spacing={{ xs: 6, md: 4 }}>

//           {/* Brand */}
//           <Grid item xs={12} md={3}>
//             <Typography variant="h5" sx={{ fontWeight: 800, mb: 2, color: "#111827", letterSpacing: 1 }}>
//               MyStore
//             </Typography>
//             <Typography sx={{ color: "#64748b", fontSize: "0.95rem", lineHeight: 1.7, mb: 3 }}>
//               Shop premium electronics, jewelry, and stylish fashion for men & women. Curated collections for every occasion.
//             </Typography>
//             <Stack direction="row" spacing={1} flexWrap="wrap" justifyContent={{ xs: "center", md: "flex-start" }}>
//               {[Facebook, Instagram, Twitter, LinkedIn].map((Icon, i) => (
//                 <IconButton
//                   key={i}
//                   sx={{
//                     color: "#64748b",
//                     border: "1px solid #e5e7eb",
//                     bgcolor: "#fff",
//                     "&:hover": { 
//                       bgcolor: "#2563eb", 
//                       color: "#fff", 
//                       borderColor: "#2563eb",
//                       transform: "translateY(-3px) scale(1.1)" 
//                     },
//                     transition: "all 0.3s",
//                   }}
//                 >
//                   <Icon />
//                 </IconButton>
//               ))}
//             </Stack>
//           </Grid>

//           {/* Explore */}
//           <Grid item xs={12} sm={6} md={2}>
//             <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 2, color: "#111827" }}>
//               Explore
//             </Typography>
//             <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5 }}>
//               {["Home", "Categories", "Products", "Contact"].map((item) => (
//                 <Typography key={item} component={Link} to="/" sx={linkStyle}>
//                   {item}
//                 </Typography>
//               ))}
//             </Box>
//           </Grid>

//           {/* Categories */}
//           <Grid item xs={12} sm={6} md={2}>
//             <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 2, color: "#111827" }}>
//               Categories
//             </Typography>
//             <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5 }}>
//               {["electronics", "jewelery", "men's clothing", "women's clothing"].map((cat) => (
//                 <Typography key={cat} component={Link} to={`/category/${encodeURIComponent(cat)}`} sx={linkStyle}>
//                   {cat}
//                 </Typography>
//               ))}
//             </Box>
//           </Grid>

//           {/* Newsletter */}
//           <Grid item xs={12} md={5}>
//             <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 2, color: "#111827" }}>
//               Stay Updated
//             </Typography>
//             <Typography sx={{ color: "#64748b", fontSize: "0.9rem", mb: 3 }}>
//               Subscribe to get the latest offers, deals, and new arrivals.
//             </Typography>
//             <Box sx={{ display: "flex", flexDirection: { xs: "column", sm: "row" }, gap: 1, alignItems: "center" }}>
//               <TextField
//                 placeholder="Your email"
//                 variant="outlined"
//                 size="small"
//                 sx={{
//                   width: { xs: "100%", sm: "auto" },
//                   flex: { sm: 1 },
//                   backgroundColor: "#fff",
//                   borderRadius: 2,
//                   "& .MuiOutlinedInput-root": {
//                     "& fieldset": { borderColor: "#e5e7eb" },
//                     "&:hover fieldset": { borderColor: "#2563eb" },
//                   },
//                 }}
//               />
//               <Button
//                 variant="contained"
//                 sx={{ 
//                   backgroundColor: "#2563eb",
//                   "&:hover": { backgroundColor: "#1d4ed8" },
//                   borderRadius: 2,
//                   width: { xs: "100%", sm: "auto" },
//                   minWidth: { sm: "120px" }
//                 }}
//               >
//                 Subscribe
//               </Button>
//             </Box>
//           </Grid>
//         </Grid>

//         <Divider sx={{ my: 6, borderColor: "#e5e7eb" }} />

//         {/* Bottom bar */}
//         <Box sx={{ display: "flex", flexDirection: { xs: "column", md: "row" }, justifyContent: "space-between", alignItems: "center", gap: 2 }}>
//           <Typography sx={{ color: "#94a3b8", fontSize: "0.85rem", textAlign: { xs: "center", md: "left" } }}>
//             &copy; {new Date().getFullYear()} MyStore. All Rights Reserved.
//           </Typography>
//           <Stack direction="row" spacing={3} flexWrap="wrap" justifyContent={{ xs: "center", md: "flex-end" }}>
//             {["Privacy", "Terms", "Cookies"].map((item) => (
//               <Typography 
//                 key={item} 
//                 component={Link} 
//                 to="/" 
//                 sx={bottomLinkStyle}
//               >
//                 {item}
//               </Typography>
//             ))}
//           </Stack>
//         </Box>
//       </Container>
//     </Box>
//   );
// }
import React from "react";
import {
  Box,
  Container,
  Grid,
  Typography,
  Stack,
  TextField,
  Button,
  Divider,
  Link as MuiLink,
} from "@mui/material";

export default function Footer() {
  return (
    <Box
      sx={{
        mt: 8,
        background: "#f3f4f6",
        color: "#111827",
        pt: 6,
        pb: 3,
        borderTop: "1px solid #e5e7eb",
      }}
    >
      <Container maxWidth="lg">
        <Grid
          container
          spacing={4}
          sx={{
            textAlign: { xs: "center", sm: "center", md: "left" },
            justifyContent: 'center'
          }}
        >
          {/* BRAND */}
          <Grid item xs={12} sm={12} md={12} lg={3}>
            <Typography sx={{ fontWeight: 800, fontSize: 30, mb: 1 }}>
              MyStore
            </Typography>
            <Typography sx={{ color: "#6b7280" }}>
              Premium products. Secure shopping. Smooth experience.
            </Typography>
          </Grid>

          {/* SHOP */}
          <Grid item xs={12} sm={6} md={6} lg={3}>
            <FooterTitle>Shop</FooterTitle>
            <Stack spacing={1} alignItems={{ xs: "center", sm: "flex-start" }}>
              <FooterLink>All Products</FooterLink>
              <FooterLink>Categories</FooterLink>
              <FooterLink>New Arrivals</FooterLink>
              <FooterLink>Best Sellers</FooterLink>
            </Stack>
          </Grid>

          {/* SUPPORT */}
          <Grid item xs={12} sm={6} md={6} lg={3}>
            <FooterTitle>Support</FooterTitle>
            <Stack spacing={1} alignItems={{ xs: "center", sm: "flex-start" }}>
              <FooterLink>Help Center</FooterLink>
              <FooterLink>Privacy Policy</FooterLink>
              <FooterLink>Terms & Conditions</FooterLink>
              <FooterLink>Contact Us</FooterLink>
            </Stack>
          </Grid>

          {/* NEWSLETTER */}
          <Grid item xs={12} sm={12} md={12} lg={3}>
            <FooterTitle>Stay Updated</FooterTitle>
            <Typography sx={{ color: "#6b7280", mb: 2 }}>
              Subscribe to get exclusive offers & updates
            </Typography>

            <Stack
              direction={{ xs: "column", sm: "row" }}
              spacing={2}
              justifyContent={{ xs: "center", sm: "flex-start" }}
            >
              <TextField
                placeholder="Enter your email"
                fullWidth
                sx={{
                  background: "white",
                  borderRadius: "10px",
                }}
                variant="outlined"
              />

              <Button
                variant="contained"
                sx={{
                  background: "#2563eb",
                  textTransform: "none",
                  px: 3,
                  borderRadius: 2,
                  "&:hover": { background: "#1d4ed8" },
                }}
              >
                Subscribe
              </Button>
            </Stack>
          </Grid>
        </Grid>

        <Divider sx={{ my: 4 }} />

        <Typography
          sx={{
            textAlign: "center",
            color: "#6b7280",
            fontSize: 14,
          }}
        >
          © {new Date().getFullYear()} MyStore — All Rights Reserved.
        </Typography>
      </Container>
    </Box>
  );
}

function FooterLink({ children }) {
  return (
    <MuiLink
      underline="none"
      sx={{
        color: "#4b5563",
        fontSize: 15,
        cursor: "pointer",
        "&:hover": {
          color: "#111827",
          transform: "translateX(4px)",
          transition: "0.25s",
        },
      }}
    >
      {children}
    </MuiLink>
  );
}

function FooterTitle({ children }) {
  return (
    <Typography sx={{ fontWeight: 700, mb: 2, fontSize: 18 }}>
      {children}
    </Typography>
  );
}
