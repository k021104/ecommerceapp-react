// import React, { useState } from "react";
// import {
//     Box,
//     TextField,
//     Typography,
//     Button,
//     Card,
//     CardContent
// } from "@mui/material";
// import { Link } from "react-router-dom";

// export default function Register() {

//     const [username, setUsername] = useState("");
//     const [password, setPassword] = useState("");

//     const handleRegister = async (e) => {
//         e.preventDefault();

//         try {
//             const res = await fetch("https://fakestoreapi.com/users", {
//                 method: "POST",
//                 headers: { "Content-Type": "application/json" },
//                 body: JSON.stringify({
//                     email: `${username}@gmail.com`,
//                     username,
//                     password
//                 })
//             });

//             const data = await res.json();
//             console.log(data);

//             if (data && data.id) {
//                 alert("Registered Successfully 🎉");
//             } else {
//                 alert("Registration Failed ❌");
//             }

//         } catch (error) {
//             alert("Something went wrong ❌");
//         }
//     };

//     return (
//         <Box
//             sx={{
//                 minHeight: "100vh",
//                 display: "flex",
//                 justifyContent: "center",
//                 alignItems: "center",
//                 background: "linear-gradient(135deg,#e0e7ff,#fdf2f8)"
//             }}
//         >
//             <Card sx={{
//                 width: { xs: "90%", sm: 400 },
//                 borderRadius: "15px",
//                 boxShadow: "0 10px 30px rgba(0,0,0,.2)"
//             }}>
//                 <CardContent>
//                     <Typography
//                         variant="h4"
//                         sx={{ textAlign: "center", fontWeight: 700, mb: 3 }}
//                     >
//                         Register
//                     </Typography>

//                     <form onSubmit={handleRegister}>
//                         <TextField
//                             label="Username"
//                             fullWidth
//                             sx={{ mb: 2 }}
//                             value={username}
//                             onChange={(e) => setUsername(e.target.value)}
//                         />

//                         <TextField
//                             label="Password"
//                             type="password"
//                             fullWidth
//                             sx={{ mb: 3 }}
//                             value={password}
//                             onChange={(e) => setPassword(e.target.value)}
//                         />

//                         <Button
//                             type="submit"
//                             fullWidth
//                             variant="contained"
//                             sx={{ py: 1, fontSize: "16px", borderRadius: "10px" }}
//                         >
//                             Register
//                         </Button>
//                     </form>

//                     <Typography sx={{ textAlign: "center", mt: 2, color: "gray" }}>
//                         Already have an account?
//                         <Link to="/login" style={{ color: "#1976d2", textDecoration: "none" }}>
//                             Login
//                         </Link>
//                     </Typography>

//                 </CardContent>
//             </Card>
//         </Box>
//     );
// }


import React, { useContext, useState } from "react";
import { AuthContext } from "../Context/AuthContext";
import { Box, TextField, Typography, Button, Card, CardContent } from "@mui/material";
import { Link, useNavigate } from "react-router-dom";
import { useEffect } from "react";

export default function Register() {

    const { register } = useContext(AuthContext);
    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [errors, setErrors] = useState({});

    const validate = () => {
        let temp = {};

        // email check
        if (!email) temp.email = "Email is required";
        else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
            temp.email = "Enter a valid email";

        // username check
        if (!username) temp.username = "Username is required";
        else if (username.length < 4)
            temp.username = "Username must be at least 4 characters";

        // password check
        if (!password) temp.password = "Password is required";
        else if (password.length < 6)
            temp.password = "Password must be at least 6 characters";

        setErrors(temp);

        return Object.keys(temp).length === 0;
    };


    const handleRegister = (e) => {
        e.preventDefault();

        if (!validate()) return;   // ⛔ stop if validation fails

        const success = register(email, username, password);
        if (success) {
            navigate("/login");
        }
    };


    return (
        <Box sx={{ minHeight: "100vh", display: "flex", justifyContent: "center", alignItems: "center", 
        // background: "linear-gradient(135deg,#e0e7ff,#fdf2f8)" 
        }}>
            <Card sx={{ width: { xs: "90%", sm: 400 }, borderRadius: "15px", boxShadow: "0 10px 30px rgba(0,0,0,.2)" }}>
                <CardContent>
                    <Typography variant="h4" sx={{ textAlign: "center", fontWeight: 700, mb: 3 }}>Register</Typography>

                    <form onSubmit={handleRegister} autoComplete="off">
                        <TextField label="Email" fullWidth sx={{ mb: 2 }} value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            error={!!errors.email}
                            helperText={errors.email} />
                        <TextField label="Username" fullWidth sx={{ mb: 2 }} value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            error={!!errors.username}
                            helperText={errors.username}
                        />
                        <TextField label="Password" type="password" fullWidth sx={{ mb: 3 }} value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            error={!!errors.password}
                            helperText={errors.password}
                        />

                        <Button type="submit" fullWidth variant="contained" sx={{ py: 1, fontSize: "16px", borderRadius: "10px" }}>Register</Button>
                    </form>

                    <Typography sx={{ textAlign: "center", mt: 2, color: "gray" }}>
                        Already have an account?{" "}
                        <Link to="/login" style={{ color: "#1976d2", textDecoration: "none" }}>Login</Link>
                    </Typography>
                </CardContent>
            </Card>
        </Box>
    );
}
