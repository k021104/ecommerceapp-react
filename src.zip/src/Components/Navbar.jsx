import React, { useState } from "react";
import {
    AppBar,
    Toolbar,
    Typography,
    Box,
    Button,
    Badge,
    InputBase,
    Drawer,
    List,
    ListItem,
    ListItemText,
    IconButton,
    ListItemButton
} from "@mui/material";

import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import SearchIcon from "@mui/icons-material/Search";
import MenuIcon from "@mui/icons-material/Menu";
import { Link } from "react-router-dom";
import { useContext } from "react";
import { SearchContext } from "../Context/SearchContext";
import { CartContext } from "../Context/CartContext";
import { WishlistContext } from "../Context/WishlistContext";
import { AuthContext } from "../Context/AuthContext";

export default function Navbar() {

    const { searchText, setSearchText } = useContext(SearchContext);
    const { cart } = useContext(CartContext);
    const { wishlist } = useContext(WishlistContext);

    const { token, logout } = useContext(AuthContext);

    const [open, setOpen] = useState(false);

    return (
        <>
            <AppBar
                sx={{
                    background: "#ffffff",
                    color: "#111827",
                    boxShadow: "0px 2px 10px rgba(0,0,0,0.08)",
                    paddingY: { xs: 0.5, md: 1 },   // smaller on mobile
                }}
            >
                <Toolbar sx={{ gap: { xs: 1, md: 3 } }}>

                    {/* Mobile Menu Button */}
                    <IconButton
                        sx={{ display: { xs: "block", md: "none" }, color: "#111827" }}
                        onClick={() => setOpen(true)}
                    >
                        <MenuIcon />
                    </IconButton>

                    {/* Logo */}
                    <Typography variant="h5" sx={{
                        fontWeight: 600,
                        flexGrow: { xs: 1, md: 0 },
                        fontSize: { xs: "18px", md: "24px" }
                    }}>
                        MyStore
                    </Typography>

                    {/* Search */}
                    <Box
                        sx={{
                            flexGrow: 1,
                            maxWidth: { xs: 220, sm: 400, md: 500 },
                            display: { xs: "none", sm: "flex" },
                            alignItems: "center",
                            background: "#f3f4f6",
                            padding: { xs: "4px 8px", md: "6px 12px" },
                            borderRadius: "50px",
                            border: "1px solid #e5e7eb"
                        }}
                    >
                        <SearchIcon sx={{ color: "#6b7280" }} />
                        <InputBase placeholder="Search..." sx={{ ml: 1, flex: 1, fontSize: { xs: "12px", md: "14px" } }} onChange={(e) => setSearchText(e.target.value)} />
                    </Box>

                    {/* Desktop Links */}
                    <Box sx={{ display: { xs: "none", md: "flex" }, gap: 2 }}>
                        <Button component={Link} to="/" sx={{ color: "#111827", fontSize: "14px" }}>
                            Home
                        </Button>
                        <Button component={Link} to="/categories" sx={{ color: "#111827", fontSize: "14px" }}>
                            Categories
                        </Button>
                        <Button component={Link} to="/products" sx={{ color: "#111827", fontSize: "14px" }}>
                            Products
                        </Button>
                        <Button component={Link} to="/contact" sx={{ color: "#111827", fontSize: "14px" }}>
                            Contact
                        </Button>
                    </Box>

                    {/* Login Icon */}
                    {/* <Link to="/login" style={{ color: "inherit", textDecoration: "none", marginLeft: 8 }}>
                        <AccountCircleIcon sx={{ fontSize: { xs: 24, md: 30 } }} />
                    </Link> */}
                    {token ? (
                        <Button variant="outlined" onClick={logout}>Logout</Button>
                    ) : (
                        <Link to="/login" style={{ color: "inherit", textDecoration: "none" }}>
                            <AccountCircleIcon sx={{ fontSize: { xs: 24, md: 30 } }} />
                        </Link>
                    )}

                    {/* Wishlist Icon */}
                    <Link to="/wishlist" style={{ color: "inherit", textDecoration: "none", marginLeft: 8 }}>
                        <Badge badgeContent={wishlist?.length || 0} color="error" showZero>
                            <FavoriteBorderIcon sx={{ fontSize: { xs: 22, md: 28 } }} />
                        </Badge>
                    </Link>

                    {/* Cart */}
                    <Link to="/cart" style={{ color: "inherit", textDecoration: "none" }}>
                        <Badge badgeContent={cart?.length || 0} color="error" sx={{ ml: 1 }} showZero>
                            <ShoppingCartIcon sx={{ fontSize: { xs: 22, md: 28 } }} />
                        </Badge>
                    </Link>

                </Toolbar>
            </AppBar>

            {/* Drawer Menu */}
            <Drawer open={open} onClose={() => setOpen(false)}>
                <List sx={{ width: 250 }}>

                    <ListItem disablePadding>
                        <ListItemButton component={Link} to="/" onClick={() => setOpen(false)}>
                            <ListItemText primary="Home" />
                        </ListItemButton>
                    </ListItem>

                    <ListItem disablePadding>
                        <ListItemButton component={Link} to="/categories" onClick={() => setOpen(false)}>
                            <ListItemText primary="Categories" />
                        </ListItemButton>
                    </ListItem>

                    <ListItem disablePadding>
                        <ListItemButton component={Link} to="/products" onClick={() => setOpen(false)}>
                            <ListItemText primary="Products" />
                        </ListItemButton>
                    </ListItem>

                    <ListItem disablePadding>
                        <ListItemButton component={Link} to="/contact" onClick={() => setOpen(false)}>
                            <ListItemText primary="Contact" />
                        </ListItemButton>
                    </ListItem>

                </List>
            </Drawer>
        </>
    );
}
