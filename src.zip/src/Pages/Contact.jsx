import React from "react";
import { Box, Typography, TextField, Button, Grid } from "@mui/material";

export default function Contact() {
  return (
    <Box sx={{ minHeight: "90vh", backgroundColor: "#fcfcfc", py: { xs: 6, md: 12 } }}>
      <Grid
        container
        maxWidth="lg"
        sx={{
          margin: "auto",
          backgroundColor: "#fff",
          borderRadius: 4,
          overflow: "hidden",
          boxShadow: "0 15px 40px rgba(0,0,0,0.1)",
          px: { xs: 3, sm: 6, md: 8 },
          py: { xs: 6, md: 10 },
        }}
      >
        {/* Contact Form */}
        <Grid item xs={12} md={8} sx={{ margin: "auto" }}>
          <Typography
            variant="overline"
            sx={{ color: "#6b7280", fontWeight: 600, letterSpacing: 2, mb: 1 }}
          >
            Contact Us
          </Typography>
          <Typography
            variant="h3"
            sx={{
              fontWeight: 800,
              color: "#111827",
              mt: 1,
              mb: 2,
              fontSize: { xs: "2rem", sm: "2.5rem", md: "3rem" },
            }}
          >
            Get in Touch
          </Typography>
          <Typography
            sx={{
              color: "#6b7280",
              mb: 4,
              fontSize: { xs: "0.9rem", sm: "1rem", md: "1.1rem" },
            }}
          >
            Have questions or feedback? We'd love to hear from you. Fill out the form and our team will respond promptly.
          </Typography>

          <Box
            component="form"
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 3,
            }}
          >
            <TextField
              label="Full Name"
              variant="outlined"
              fullWidth
              sx={{
                "& .MuiOutlinedInput-root": { borderRadius: 3 },
                "& .MuiInputLabel-root": { fontWeight: 600 },
              }}
            />
            <TextField
              label="Email Address"
              variant="outlined"
              fullWidth
              type="email"
              sx={{
                "& .MuiOutlinedInput-root": { borderRadius: 3 },
                "& .MuiInputLabel-root": { fontWeight: 600 },
              }}
            />
            <TextField
              label="Message"
              variant="outlined"
              fullWidth
              multiline
              rows={5}
              sx={{
                "& .MuiOutlinedInput-root": { borderRadius: 3 },
                "& .MuiInputLabel-root": { fontWeight: 600 },
              }}
            />
            <Box sx={{ display: "flex", justifyContent: { xs: "center", md: "flex-start" } }}>
              <Button
                variant="contained"
                sx={{
                  backgroundColor: "#111827",
                  color: "#fff",
                  fontWeight: 700,
                  borderRadius: "30px",
                  py: 1.5,
                  px: 6,
                  textTransform: "none",
                  "&:hover": { backgroundColor: "#000" },
                  fontSize: { xs: "0.9rem", sm: "1rem", md: "1.1rem" },
                }}
              >
                Send Message
              </Button>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
}
