// import React from "react";
// import { Box, Typography, Button } from "@mui/material";

// export default function Hero() {
//     return (
//         <Box
//             sx={{
//                 mt: { xs: 8, md: 10 },  // <-- push below navbar
//                 height: { xs: 200, md: 400 },
//                 background: "linear-gradient(135deg, #f3f4f6, #ffffff)",
//                 display: "flex",
//                 flexDirection: "column",
//                 justifyContent: "center",
//                 alignItems: "center",
//                 textAlign: "center",
//                 px: 2,
//             }}
//         >
//             <Typography
//                 variant="h3"
//                 sx={{
//                     fontWeight: 700,
//                     fontSize: { xs: "24px", md: "48px" },
//                     mb: 2
//                 }}
//             >
//                 Welcome to MyStore
//             </Typography>

//             <Typography
//                 sx={{
//                     fontSize: { xs: "14px", md: "18px" },
//                     mb: 3,
//                     color: "#555"
//                 }}
//             >
//                 Find your favorite products with amazing deals
//             </Typography>

//             <Button
//                 variant="contained"
//                 sx={{
//                     background: "#111827",
//                     color: "#fff",
//                     padding: { xs: "6px 14px", md: "10px 20px" },
//                     fontSize: { xs: "12px", md: "16px" },
//                     "&:hover": { background: "#000" }
//                 }}
//             >
//                 Shop Now
//             </Button>
//         </Box>
//     );
// }


import React from "react";
import { Box, Typography, Button, Stack, Container } from "@mui/material";
import heroimg from '../Assets/images/hero_image.jpg';

export default function Hero() {
    return (
        <Box
            sx={{
                width: "100%",
                background: "linear-gradient(135deg, #ffffff 0%, #f6f7fb 40%, #eef2ff 100%)",
                py: { xs: 6, sm: 8, md: 12 }, // Responsive padding top & bottom
            }}
        >
            <Container
                maxWidth="lg"
                sx={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    flexDirection: { xs: "column-reverse", sm: "row" }, // Image below text on mobile
                    gap: { xs: 4, md: 6 },
                }}
            >
                {/* LEFT SIDE TEXT */}
                <Box sx={{ flex: 1, textAlign: { xs: "center", sm: "left" } }}>
                    <Typography
                        data-aos="fade-up"
                        data-aos-delay="100"
                        sx={{
                            color: "#2563eb",
                            fontWeight: 600,
                            letterSpacing: "1px",
                            mb: 1,
                            fontSize: { xs: "14px", sm: "16px" },
                        }}
                    >
                        Premium Collection
                    </Typography>

                    <Typography
                        data-aos="fade-up"
                        data-aos-delay="200"
                        sx={{
                            fontWeight: 800,
                            color: "#0f172a",
                            fontSize: { xs: "28px", sm: "36px", md: "48px" }, // scales nicely
                            lineHeight: { xs: 1.2, sm: 1.3 },
                            mb: 2,
                        }}
                    >
                        Discover Your Next Favorite Product
                    </Typography>

                    <Typography
                        sx={{
                            color: "#52525b",
                            fontSize: { xs: "14px", sm: "16px", md: "18px" },
                            lineHeight: 1.7,
                            maxWidth: { xs: "100%", sm: 480, md: 520 },
                            mb: 3,
                        }}
                    >
                        High-quality, stylish, and affordable products for your daily life.
                        Shop confidently with great offers and fast delivery.
                    </Typography>

                    <Stack
                        direction={{ xs: "column", sm: "row" }}
                        spacing={2}
                        justifyContent={{ xs: "center", sm: "flex-start" }}
                        data-aos="fade-up"
                        data-aos-delay="300"
                    >
                        <Button
                            variant="contained"
                            sx={{
                                bgcolor: "#2563eb",
                                px: { xs: 5, sm: 4 },
                                py: { xs: 1.5, sm: 1.3 },
                                borderRadius: "10px",
                                fontWeight: 600,
                                fontSize: { xs: "14px", sm: "16px" },
                                "&:hover": { bgcolor: "#1e40af" },
                            }}
                        >
                            Shop Now
                        </Button>

                        <Button
                            variant="outlined"
                            sx={{
                                px: { xs: 5, sm: 4 },
                                py: { xs: 1.5, sm: 1.3 },
                                borderRadius: "10px",
                                borderColor: "#d1d5db",
                                color: "#0f172a",
                                fontWeight: 600,
                                fontSize: { xs: "14px", sm: "16px" },
                                "&:hover": { borderColor: "#9ca3af", bgcolor: "#f4f4f4" },
                            }}
                        >
                            Explore
                        </Button>
                    </Stack>
                </Box>

                {/* RIGHT SIDE IMAGE */}
                <Box
                    sx={{
                        flex: 1,
                        display: "flex",
                        justifyContent: { xs: "center", sm: "flex-end" },
                    }}
                >
                    <Box
                        component="img"
                        src={heroimg}
                        alt="Shopping"
                        data-aos="fade-left"
                        data-aos-delay="400"
                        sx={{
                            width: { xs: "80%", sm: "100%", md: "95%" },
                            maxWidth: 560,
                            borderRadius: "22px",
                            objectFit: "cover",
                            boxShadow: "0 25px 50px rgba(0,0,0,.12), 0 10px 25px rgba(0,0,0,.08)",
                        }}
                    />
                </Box>
            </Container>
        </Box>
    );
}
