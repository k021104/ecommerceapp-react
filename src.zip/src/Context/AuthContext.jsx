// import { createContext, useState, useEffect } from "react";

// export const AuthContext = createContext();

// export default function AuthProvider({ children }) {

//     const [token, setToken] = useState(null);

//     // Load token from localStorage when app opens
//     useEffect(() => {
//         const savedToken = localStorage.getItem("token");
//         if (savedToken) setToken(savedToken);
//     }, []);

//     // LOGIN FUNCTION
//     const login = async (username, password) => {
//         try {
//             const res = await fetch("https://fakestoreapi.com/auth/login", {
//                 method: "POST",
//                 headers: { "Content-Type": "application/json" },
//                 body: JSON.stringify({ username, password })
//             });

//             const data = await res.json();

//             if (data.token) {
//                 setToken(data.token);
//                 localStorage.setItem("token", data.token);
//                 alert("Login Successful 🎉");
//                 return true;
//             } else {
//                 alert("Invalid Username or Password ❌");
//                 return false;
//             }

//         } catch (error) {
//             alert("Something went wrong!");
//             return false;
//         }
//     };

//     // LOGOUT FUNCTION
//     const logout = () => {
//         setToken(null);
//         localStorage.removeItem("token");
//         alert("Logged Out Successfully 👋");
//     };

//     return (
//         <AuthContext.Provider value={{ token, login, logout }}>
//             {children}
//         </AuthContext.Provider>
//     );
// }


import { createContext, useState, useEffect } from "react";

export const AuthContext = createContext();

export default function AuthProvider({ children }) {

    const [token, setToken] = useState(null); // Login token
    const [currentUser, setCurrentUser] = useState(null); // Currently logged in user

    // Load token & user from localStorage when app opens
    useEffect(() => {
        const savedToken = localStorage.getItem("token");
        const savedUser = localStorage.getItem("currentUser");
        if (savedToken) setToken(savedToken);
        if (savedUser) setCurrentUser(JSON.parse(savedUser));
    }, []);

    // LOGIN FUNCTION
    const login = (username, password) => {
        // Load users from localStorage
        const users = JSON.parse(localStorage.getItem("users")) || [];

        const foundUser = users.find(
            (u) => u.username === username && u.password === password
        );

        if (foundUser) {
            const dummyToken = Math.random().toString(36).substr(2); 
            setToken(dummyToken);
            setCurrentUser(foundUser);
            localStorage.setItem("token", dummyToken);
            localStorage.setItem("currentUser", JSON.stringify(foundUser));
            alert("Login Successful 🎉");
            return true;
        } else {
            alert("Invalid Username or Password ❌");
            return false;
        }
    };

    // REGISTER FUNCTION
    const register = (email, username, password) => {
        // Load users from localStorage
        const users = JSON.parse(localStorage.getItem("users")) || [];

        // Check if user already exists
        const exist = users.find((u) => u.username === username || u.email === email);
        if (exist) {
            alert("User already exists ❌");
            return false;
        }

        const newUser = { email, username, password };
        users.push(newUser);
        localStorage.setItem("users", JSON.stringify(users));
        alert("Registered Successfully 🎉");
        return true;
    };

    // LOGOUT FUNCTION
    const logout = () => {
        setToken(null);
        setCurrentUser(null);
        localStorage.removeItem("token");
        localStorage.removeItem("currentUser");
        alert("Logged Out Successfully 👋");
    };

    return (
        <AuthContext.Provider value={{ token, currentUser, login, register, logout }}>
            {children}
        </AuthContext.Provider>
    );
}
