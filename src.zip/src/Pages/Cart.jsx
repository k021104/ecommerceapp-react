import React, { useContext } from "react";
import { CartContext } from "../Context/CartContext";
import { Box, Typography, Button, Divider } from "@mui/material";
import { Link } from "react-router-dom";

export default function Cart() {
  const {
    cart,
    removeFromCart,
    increaseQty,
    decreaseQty,
    getSubtotal,
    getTotal,
  } = useContext(CartContext);

  return (
    <Box sx={{ p: { xs: 2, sm: 4, md: 6 } }}>
      <Typography
        variant="h4"
        sx={{ fontWeight: 700, mb: 4, textAlign: "center" }}
      >
        Your Cart
      </Typography>

      {cart.length === 0 ? (
        <Typography
          variant="h6"
          sx={{ color: "gray", textAlign: "center", mt: 5 }}
        >
          Your cart is empty 😔
        </Typography>
      ) : (
        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            gap: 4,
          }}
        >
          {/* ---------------- LEFT SIDE : CART ITEMS ---------------- */}
          <Box sx={{ flex: 2, display: "flex", flexDirection: "column", gap: 3 }}>
            {cart.map((item) => (
              <Box
                key={item.id}
                sx={{
                  display: "flex",
                  flexDirection: { xs: "column", sm: "row" },
                  alignItems: "center",
                  justifyContent: "space-between",
                  background: "#fff",
                  p: 2,
                  borderRadius: "12px",
                  boxShadow: "0 8px 25px rgba(0,0,0,.08)",
                  gap: 2,
                }}
              >
                {/* Product Image */}
                <Box
                  sx={{
                    width: { xs: "100%", sm: "90px" },
                    height: 90,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background: "#f3f4f6",
                    borderRadius: "10px",
                    p: 1,
                  }}
                >
                  <img
                    src={item.image}
                    alt={item.title}
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "contain",
                    }}
                  />
                </Box>

                {/* Title */}
                <Typography
                  sx={{
                    flex: 1,
                    fontWeight: 600,
                    textAlign: { xs: "center", sm: "left" },
                    fontSize: { xs: "14px", sm: "16px" },
                  }}
                >
                  {item.title.length > 40
                    ? item.title.slice(0, 40) + "..."
                    : item.title}
                </Typography>

                {/* Price */}
                <Typography
                  sx={{
                    fontWeight: 700,
                    minWidth: 70,
                    textAlign: "center",
                    fontSize: "16px",
                  }}
                >
                  ${item.price}
                </Typography>

                {/* Quantity Controls */}
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                    // bgcolor: "#f3f4f6",
                    p: "6px 10px",
                    borderRadius: "5px",
                  }}
                >
                  <Button
                    variant="outlined"
                    size="small"
                    onClick={() => decreaseQty(item.id)}
                  >
                    -
                  </Button>

                  <Typography sx={{ fontWeight: 700 }}>
                    {item.quantity}
                  </Typography>

                  <Button
                    variant="outlined"
                    size="small"
                    onClick={() => increaseQty(item.id)}
                  >
                    +
                  </Button>
                </Box>

                {/* Remove Button */}
                <Button
                  variant="contained"
                  color="error"
                  sx={{ minWidth: 90 }}
                  onClick={() => removeFromCart(item.id)}
                >
                  Remove
                </Button>
              </Box>
            ))}
          </Box>

          {/* ---------------- RIGHT SIDE : TOTAL BOX ---------------- */}
          <Box
            sx={{
              flex: 1,
              height: "fit-content",
              background: "#fff",
              p: 3,
              borderRadius: "12px",
              boxShadow: "0 8px 25px rgba(0,0,0,.1)",
            }}
          >
            <Typography sx={{ fontSize: 20, fontWeight: 700, mb: 2 }}>
              Order Summary
            </Typography>

            <Divider sx={{ mb: 2 }} />

            <Typography sx={{ fontSize: 16, fontWeight: 500, mb: 1 }}>
              Subtotal:{" "}
              <span style={{ fontWeight: 700 }}>
                ${getSubtotal().toFixed(2)}
              </span>
            </Typography>

            <Typography sx={{ fontSize: 16, fontWeight: 500, mb: 1 }}>
              Shipping: <span style={{ fontWeight: 700 }}>$0.00</span>
            </Typography>

            <Typography sx={{ fontSize: 16, fontWeight: 500 }}>
              Tax: <span style={{ fontWeight: 700 }}>$0.00</span>
            </Typography>

            <Divider sx={{ my: 2 }} />

            <Typography sx={{ fontSize: 20, fontWeight: 800 }}>
              Grand Total: ${getTotal().toFixed(2)}
            </Typography>

            <Button
              component={Link}
              to="/checkout"
              variant="contained"
              sx={{
                width: "100%",
                mt: 3,
                background: "#111827",
                "&:hover": { background: "#000" },
              }}
            >
              Proceed to Checkout
            </Button>
          </Box>
        </Box>
      )}
    </Box>
  );
}
