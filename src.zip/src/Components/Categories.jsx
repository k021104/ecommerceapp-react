// import React, { useEffect, useState } from "react";
// import { Box, Typography, Card, Button } from "@mui/material";
// import cat1 from '../Assets/images/electonics_category.webp';
// import cat2 from '../Assets/images/jewellery_category.jpg';
// import cat3 from '../Assets/images/men_category.jpg';
// import cat4 from '../Assets/images/women_category.webp';
// import { Link } from "react-router-dom";

// export default function Categories() {

//   const categoryImages = {
//     "electronics": cat1,
//     "jewelery": cat2,
//     "men's clothing": cat3,
//     "women's clothing": cat4,
//   };


//   const [categories, setCategories] = useState([]);

//   useEffect(() => {
//     fetch("https://fakestoreapi.com/products/categories")
//       .then(res => res.json())
//       .then(result => setCategories(result))
//       .catch(err => console.log(err));
//   }, []);

//   return (
//     <Box sx={{ p: { xs: 2, md: 6 } }}>

//       {/* Heading */}
//       <Typography
//         variant="h4"
//         sx={{
//           mb: 4,
//           fontWeight: 700,
//           color: "#111827",
//           textAlign: "center"
//         }}
//       >
//         Shop By Categories
//       </Typography>

//       {/* Categories Grid */}
//       <Box
//         sx={{
//           display: "grid",
//           gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(4, 1fr)" },
//           gap: 3
//         }}
//       >
//         {categories.map((cat, i) => (
//           <Card
//             key={i}
//             sx={{
//               p: 2,
//               borderRadius: "14px",
//               border: "1px solid #e5e7eb",
//               textAlign: "center",
//               color: "#111827",
//               display: "flex",
//               flexDirection: "column",
//               justifyContent: "space-between",
//               height: 280,
//               transition: "0.3s",
//               boxShadow: "0px 5px 10px rgba(0,0,0,0.06)",
//               "&:hover": {
//                 transform: "translateY(-6px)",
//                 boxShadow: "0px 12px 25px rgba(0,0,0,0.12)"
//               }
//             }}
//           >

//             {/* IMAGE BOX */}
//             <Box
//               sx={{
//                 width: "100%",
//                 height: 140,
//                 borderRadius: "10px",
//                 background: "#f3f4f6",
//                 display: "flex",
//                 alignItems: "center",
//                 justifyContent: "center"
//               }}
//             >
//               <img
//                 src={categoryImages[cat]}
//                 alt={cat}
//                 style={{
//                   width: "85%",
//                   height: "85%",
//                   objectFit: "contain"
//                 }}
//               />
//             </Box>

//             <Typography sx={{ fontWeight: 700, textTransform: "capitalize", mt: 1 }}>
//               {cat}
//             </Typography>

//             <Button
//               component={Link}
//               to={`/category/${cat}`}
//               variant="contained"
//               sx={{
//                 textTransform: "none",
//                 background: "#111827",
//                 "&:hover": { background: "#000" }
//               }}
//             >
//               View Products
//             </Button>

//           </Card>
//         ))}
//       </Box>
//     </Box>
//   );
// }


import React, { useEffect, useState } from "react";
import { Box, Typography, Card, Button, CardContent } from "@mui/material";
import { Link } from "react-router-dom";

import cat1 from '../Assets/images/electonics_category.webp';
import cat2 from '../Assets/images/jewelery_category.webp';
import cat3 from '../Assets/images/mens_clothing.webp';
import cat4 from '../Assets/images/womens_category_img.jpg';

export default function Categories() {

  const categoryImages = {
    "electronics": cat1,
    "jewelery": cat2,
    "men's clothing": cat3,
    "women's clothing": cat4,
  };

  const [categories, setCategories] = useState([]);

  useEffect(() => {
    fetch("https://fakestoreapi.com/products/categories")
      .then(res => res.json())
      .then(result => setCategories(result))
      .catch(err => console.log(err));
  }, []);

  return (
    <Box sx={{ p: { xs: 3, md: 8 }, backgroundColor: "#fcfcfc" }}>

      {/* Header */}
      <Box sx={{ textAlign: "center", mb: 6 }}>
        <Typography
          data-aos="fade-up"
          variant="overline"
          sx={{ color: "#6b7280", fontWeight: 600, letterSpacing: 2 }}
        >
          Curated Collections
        </Typography>

        <Typography
          data-aos="fade-up"
          variant="h3"
          sx={{
            fontWeight: 800,
            color: "#111827",
            mt: 1,
            fontSize: { xs: "2rem", md: "3rem" },
          }}
        >
          Shop by Category
        </Typography>
      </Box>

      {/* Grid */}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "1fr 1fr",
            md: "1fr 1fr",
            lg: "1fr 1fr"
          },
          gap: 5,
          maxWidth: "1200px",
          margin: "auto"
        }}
      >
        {categories.map((cat, i) => (
          <Card
            data-aos="fade-up"
            data-aos-delay={i * 300}
            key={i}
            sx={{
              position: "relative",
              borderRadius: "22px",
              overflow: "hidden",
              height: { md: 420, sm: 340, xs: 260 },
              boxShadow: "0 15px 35px rgba(0,0,0,0.12)",
              border: "none",

              "&:hover .category-image": {
                transform: "scale(1.12)",
              },

              "&:hover .view-btn": {
                opacity: 1,
                transform: "translateY(0)",
              }
            }}
          >

            {/* IMAGE */}
            <Box
              className="category-image"
              sx={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                backgroundImage: `url(${categoryImages[cat]})`,
                backgroundSize: "cover",
                backgroundPosition: "center",
                backgroundRepeat: "no-repeat",
                transition: "transform 1s ease",

                "&::after": {
                  content: '""',
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: "100%",
                  height: "100%",
                  background: "linear-gradient(to top, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0) 60%)",
                },
              }}
            />

            {/* TEXT */}
            <CardContent
              sx={{
                position: "absolute",
                bottom: 30,
                left: 0,
                right: 0,
                textAlign: "center",
                zIndex: 2,
              }}
            >
              <Typography
                variant="h4"
                sx={{
                  color: "#fff",
                  fontWeight: 800,
                  textTransform: "capitalize",
                  mb: 2,
                  letterSpacing: 1,
                }}
              >
                {cat}
              </Typography>

              <Button
                component={Link}
                to={`/category/${cat}`}
                className="view-btn"
                variant="contained"
                sx={{
                  opacity: 0,
                  transform: "translateY(20px)",
                  transition: "all 0.4s ease",
                  backgroundColor: "#ffffff",
                  color: "#000",
                  fontWeight: 700,
                  borderRadius: "40px",
                  px: 4,
                  py: 1.2,

                  "&:hover": {
                    backgroundColor: "#f3f4f6",
                  },
                }}
              >
                Explore
              </Button>
            </CardContent>
          </Card>
        ))}
      </Box>
    </Box>
  );
}
