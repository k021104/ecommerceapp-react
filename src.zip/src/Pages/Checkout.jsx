import React, { useContext, useState } from "react";
import { CartContext } from "../Context/CartContext";
import { Box, TextField, Typography, Button, Divider } from "@mui/material";

export default function Checkout() {
  const { cart, getSubtotal, getTotal } = useContext(CartContext);

  const [user, setUser] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    pincode: ""
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const validate = () => {
    let temp = {};

    temp.name = user.name ? "" : "Name is required";
    temp.email = /^\S+@\S+\.\S+$/.test(user.email) ? "" : "Valid email required";
    temp.phone = user.phone.length === 10 ? "" : "Phone must be 10 digits";
    temp.address = user.address ? "" : "Address required";
    temp.city = user.city ? "" : "City required";
    temp.pincode = user.pincode.length === 6 ? "" : "Pincode must be 6 digits";

    setErrors(temp);

    return Object.values(temp).every(x => x === "");
  };

  const handlePlaceOrder = () => {
    if (!validate()) return;

    alert("Order Placed Successfully 🎉");
  };

  return (
    <Box sx={{ p: { xs: 2, sm: 4, md: 6 } }}>
      <Typography variant="h4" sx={{ fontWeight: 700, mb: 3, textAlign: "center" }}>
        Checkout
      </Typography>

      <Box sx={{ display: "flex", flexDirection: { xs: "column", md: "row" }, gap: 4 }}>

        {/* ---------- LEFT : Billing ---------- */}
        <Box sx={{ flex: 2, background: "#fff", p: 3, borderRadius: 2, boxShadow: "0 6px 20px rgba(0,0,0,0.1)" }}>
          <Typography sx={{ fontSize: 20, fontWeight: 700, mb: 2 }}>
            Billing Details
          </Typography>

          <TextField fullWidth label="Full Name" name="name"
            value={user.name} onChange={handleChange}
            error={!!errors.name} helperText={errors.name}
            sx={{ mb: 2 }}
          />

          <TextField fullWidth label="Email" name="email"
            value={user.email} onChange={handleChange}
            error={!!errors.email} helperText={errors.email}
            sx={{ mb: 2 }}
          />

          <TextField fullWidth label="Phone" name="phone"
            value={user.phone} onChange={handleChange}
            error={!!errors.phone} helperText={errors.phone}
            sx={{ mb: 2 }}
          />

          <TextField fullWidth label="Address" name="address"
            value={user.address} onChange={handleChange}
            error={!!errors.address} helperText={errors.address}
            sx={{ mb: 2 }}
          />

          <TextField fullWidth label="City" name="city"
            value={user.city} onChange={handleChange}
            error={!!errors.city} helperText={errors.city}
            sx={{ mb: 2 }}
          />

          <TextField fullWidth label="Pincode" name="pincode"
            value={user.pincode} onChange={handleChange}
            error={!!errors.pincode} helperText={errors.pincode}
          />
        </Box>

        {/* ---------- RIGHT : Summary ---------- */}
        <Box sx={{ flex: 1, background: "#fff", p: 3, borderRadius: 2, height: "fit-content",
          boxShadow: "0 6px 20px rgba(0,0,0,0.1)" }}>

          <Typography sx={{ fontSize: 20, fontWeight: 700 }}>
            Order Summary
          </Typography>

          <Divider sx={{ my: 2 }} />

          <Typography sx={{ fontSize: 16, fontWeight: 500 }}>
            Subtotal: <b>${getSubtotal().toFixed(2)}</b>
          </Typography>

          <Typography sx={{ fontSize: 16, fontWeight: 500 }}>
            Shipping: <b>$0.00</b>
          </Typography>

          <Typography sx={{ fontSize: 16, fontWeight: 500 }}>
            Tax: <b>$0.00</b>
          </Typography>

          <Divider sx={{ my: 2 }} />

          <Typography sx={{ fontSize: 20, fontWeight: 800 }}>
            Total: ${getTotal().toFixed(2)}
          </Typography>

          <Button
            variant="contained"
            sx={{ width: "100%", mt: 3, background: "#111827", "&:hover": { background: "#000" } }}
            onClick={handlePlaceOrder}
          >
            Place Order
          </Button>
        </Box>
      </Box>
    </Box>
  );
}
